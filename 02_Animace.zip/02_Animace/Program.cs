﻿
namespace _02_Animace
{
    public static class Program
    {
       
        static void Main()
        {
            new Demo().Run();
        }
    }
}
